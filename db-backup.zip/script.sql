SET CLUSTER '';
SET DEFAULT_TABLE_TYPE 0;      
SET WRITE_DELAY 500;           
SET DEFAULT_LOCK_TIMEOUT 2000; 
SET CACHE_SIZE 16384;          
;              
CREATE USER IF NOT EXISTS GREYHOUND SALT '8a765131a0338f0c' HASH '9c94d2726c42a5f7b2ac8def32937f385bc60b2edbf6f57428880be930df598c' ADMIN;     
CREATE CACHED TABLE PUBLIC.PAGES(
    PAGE_ID INT NOT NULL,
    TITLE VARCHAR(200) NOT NULL,
    CONTENT CLOB(1073741823),
    CATEGORY BOOLEAN DEFAULT FALSE,
    PARENT_ID INT DEFAULT NULL
);               
ALTER TABLE PUBLIC.PAGES ADD CONSTRAINT PUBLIC.CONSTRAINT_4 PRIMARY KEY(PAGE_ID);              
-- 45 +/- SELECT COUNT(*) FROM PUBLIC.PAGES;   
INSERT INTO PUBLIC.PAGES(PAGE_ID, TITLE, CONTENT, CATEGORY, PARENT_ID) VALUES
(1, 'Tech', NULL, TRUE, NULL),
(2, 'Linux', NULL, TRUE, 1),
(3, 'Java', NULL, TRUE, 1),
(4, 'TODO', NULL, TRUE, NULL),
(8, '31', STRINGDECODE('Epoxy paint\nInstall lamps\nSeal air conditioners\nPaint windows, shutters\nFix carpark floor\nPass lawnmower\nPaint outside walls\nRemove tree\nPut contentions to gates'), FALSE, 4),
(9, 'Hibernate', '', TRUE, 3),
(10, 'Spring', '', TRUE, 3),
(11, 'Swing', '', TRUE, 3),
(13, 'Jython', '', TRUE, 3),
(14, 'Mapping tips', STRINGDECODE('Here are some mapping tips:\n\n- \n- '), FALSE, 9),
(15, 'Debian', '', TRUE, 2),
(16, 'Linux Mint', '', TRUE, 2),
(17, 'Application context tips', 'Some app context tips...', FALSE, 10),
(18, 'Blog', '', TRUE, NULL),
(19, 'Wishlist', '', TRUE, NULL),
(20, 'Buy', STRINGDECODE('Tricycle for Patricio\nSunglasses\nBicycle\nSmartphone/iPad\nSneakers\nGood camera'), FALSE, 19),
(21, 'Do', '', FALSE, 19),
(22, 'Subjects', STRINGDECODE('Gun Control\nNoise\nRespect\nLiberty\nIndividual Rights\nGovernment Intervention\nIndividual vs Government\nTotalitarism\nGovernment abuse\nPopulism\nMajorities abuse\nLiberalism/Libertarianism\nEntrepeneurship\nPolitical Correctness\nIslam\nOccidental Appeasement\nReligion (occassionally)\nCurrent news? (do not know about this. Might be good to use a bit of a current event and elaborate on an abstract subject)\nTechnology?\nSurviving?\nLa Maldicion de los Recursos Naturales (change wording)'), FALSE, 27),
(23, 'Interesting, innit?', '', TRUE, 18),
(25, 'Software', STRINGDECODE('Rewrite -or parallelize- greyhound in Groovy/Griffon.\n\nMultiplatform blogging software\n\nSomething for the notaries.'), FALSE, 4),
(27, 'Bloggeralismo', '', TRUE, 18),
(28, 'Subjects', STRINGDECODE('Linux\nJava SE\nSpring\nSwing\nPython\nOther techie stuff'), FALSE, 23),
(29, 'Maven', '', TRUE, 3),
(30, 'Common', STRINGDECODE('Create Java SE project:\n\tmvn archetype:generate -DarchetypeGroupId=org.apache.maven.archetypes -DgroupId=com.vgs -DartifactId=theartifact '), FALSE, 29),
(31, 'Mercurial', '', TRUE, 1),
(32, 'Create new project', STRINGDECODE('Steps to create a new project\n\n1- Create bitbucket repository projectname\n2- Create local maven project projectname\n3- In projectname directory, run ''hg init''\n4- Create projectname/.hgignore\n5- Create projectname/.hg/hgrc with these lines:\n\t[ui]\n\tusername = wintergalt <wintergalt@gmail.com>\n\t[paths]\n\tdefault = https://wintergalt@bitbucket.org/wintergalt/projectname\n6- hg commit\n7- hg push'), FALSE, 31),
(33, 'Assembly', STRINGDECODE('Good plugin for assembling jar files\n\n'), FALSE, 29),
(34, 'Python', '', TRUE, 1),
(35, 'Ruby', '', TRUE, 1),
(36, 'GUI', '', TRUE, 34),
(37, 'GUI', '', TRUE, 35),
(38, 'Camelot', 'Too young?', FALSE, 36),
(39, 'Bowline', STRINGDECODE('Homepage: bowlineapp.com\n\nBowline is a framework for making cross platform desktop applications in Ruby, HTML and JavaScript.\n\nIf you''ve ever wished creating a desktop application was as simple as creating a Rails website, Bowline''s for you.\n\nBowline respects MVC, you can design your views in HTML5/CSS3 - then bind them to your Ruby models. There''s no request/response cycle - any changes in models automatically get reflected in the view.\n\n------------\n\nPros:\n\t- Looks great\n\t- Similar to Rails\n\nCons:\n\t- New\n\t- Not too much documentation\n\t- Small userbase\n\t- Young project'), FALSE, 37),
(40, 'wxPython', 'This seems to be the best option for Python GUI development.', FALSE, 36),
(41, 'Learning vault', '', TRUE, 4),
(42, 'Learn order', STRINGDECODE('1- Groovy\n    The clear advantages of learning Groovy are that the flat learning curve and the chances of getting the thing accepted by management at work, both of them because of the Java heritage of Groovy.\n    1.2- Griffon\n        It is Grails for the desktop. It takes concepts from Grails, Swing Application Framework, etc. It has to be interesting...\n    1.3- Grails\n        It is supposed to get you started in no time and get sites done that are very flexible and fast to change/enhance (maybe at the expense of strong foundations of true Java).\n\n2- Python\n    Learning Python will give you a tool with which you can build desktop apps, web apps, system programming (scripting). Its advantages over Ruby are: clarity, availability of libraries, it is installed by default on most UN*X systems.\n    2.1- Django\n        Good for get sites up and running quickly. Not as magic as with Rails, which is a good thing for requirements that don''t fit right in the framework out-of-the-box features.\n\n3- Ruby\n    It''s VERY cool, being 100% object-oriented, almost Smalltalk-like.\n    3.1- Rails\n        It is the most popular web framework of the three. A downside is that -being the first of them all- has many oddities that the others were born without.'), FALSE, 41);           
INSERT INTO PUBLIC.PAGES(PAGE_ID, TITLE, CONTENT, CATEGORY, PARENT_ID) VALUES
(43, 'Common', STRINGDECODE('To set the PATH and other variables, edit /etc/environment. Take in account that you cannot specify variables in that file, as they will NOT be expanded into their values in /etc/environment.\n-------------\n'), FALSE, 16),
(44, 'Current', STRINGDECODE('Technical\n    Grails in Action - in progress (page 22)\n\nGeneral Programming\n    Code Complete - in process (page 41)'), FALSE, 50),
(45, 'Code complete concepts', STRINGDECODE('* Construction (coding) is the only activity in a software project that''s guaranteed to be done. Informal projects can skip design and requirements gathering to jump into construction. They can also drop testing. But they cannot drop construction.\n\n* Construction is the central activity in software development. Requirements and architecture are done before construction so that you can do construction effectively. System testing is done after construction to verify that construction has been done correctly.\n\n* Often, the source code is the only accurate description of the software. Documentation and requirements specifications can get out of date... but the code is always up to date.\n\n* Measure twice, cut once. /* These are Diego''s words: The phrase is great, but even greater should be the importance of actually CUTTING the thing. It is not worth to keep measuring and measuring to make sure the cut will not turn out wrong and eternally procrastinate the actual cut. */.'), FALSE, 23),
(46, 'Download', '', TRUE, NULL),
(47, 'Music', STRINGDECODE('Discographies\n\tThe Ramones\n\tThe Kinks\n\tThe Rolling Stones\n\tThe Beatles\n\tCreedence Clearwater Revival\n\tThe Mamas and The Papas\n\tThe Beach Boys\n\nMovies\n\tNo Direction Home'), FALSE, 46),
(48, 'Groovy', '', TRUE, 1),
(49, 'info', STRINGDECODE('Homepage: groovy.codehaus.org\n\n'), FALSE, 48),
(50, 'Reading', '', TRUE, 4),
(51, 'Planned', STRINGDECODE('List of books to read (see Current)\n\n    Technical\n        Griffon\n\n    General Programming\n        Code Complete - in process (page 41).\n        The Pragmatic Programmer, from Journeyman to Master\n        Refactoring: Improving the Design of Existing Code\n\n    Miscellaneous\n        The Hitchhiker''s Guide to the Galaxy\n        How to Win Friends\n        Surely You''re Joking Mr. Feynman\n        Getting Things Done\n        Zen and the Art of Motorcycle Maintenance'), FALSE, 50);    
CREATE UNIQUE INDEX PUBLIC.SQL100813084226120 ON PUBLIC.PAGES(PAGE_ID);        
CREATE CACHED TABLE PUBLIC.HIBERNATE_UNIQUE_KEY(
    NEXT_HI INT
);            
-- 1 +/- SELECT COUNT(*) FROM PUBLIC.HIBERNATE_UNIQUE_KEY;     
INSERT INTO PUBLIC.HIBERNATE_UNIQUE_KEY(NEXT_HI) VALUES
(1);   
